package com.company;

import java.util.Scanner;

public class Main {
    //A program to calculate bonuses for employees by Colby Snow
    public static void main(String[] args) {
        MorgansCalc.mainMenu();
    }

}
